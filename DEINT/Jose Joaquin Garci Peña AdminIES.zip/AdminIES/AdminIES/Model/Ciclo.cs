﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdminIES.Model
{
    class Ciclo
    {
        public int ID { get; set; }
        public string NombreCiclo { get; set; }
    }
}
