﻿namespace U2Act2Ej1
{
    internal class par
    {
        static void Main(string[] args)
        {
            for (int i = 1; i <= 50; i++)
            {
                if (i % 3 == 0 && i % 2 == 0)
                {
                    Console.WriteLine(i);
                }
            }

        }
    }
}