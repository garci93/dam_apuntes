/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.repaso;

/**
 *
 * @author santi
 */
public class Repaso {

    public static void main(String[] args) {
        
        
        
        
    }
}
