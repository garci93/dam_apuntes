package DAM.abstracta.test;

public class TestInmobiliaria {

}
