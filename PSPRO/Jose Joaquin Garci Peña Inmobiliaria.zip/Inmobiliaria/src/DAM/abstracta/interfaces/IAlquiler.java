package DAM.abstracta.interfaces;

public interface IAlquiler {
	public void alquilar();
}
