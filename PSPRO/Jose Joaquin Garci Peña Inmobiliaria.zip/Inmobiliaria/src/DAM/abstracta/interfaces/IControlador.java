package DAM.abstracta.interfaces;

public interface IControlador {
	public void ejecutar();
}
