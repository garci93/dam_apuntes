package DAM.abstracta.interfaces;

public interface IVenta {
	public void vender();
}
