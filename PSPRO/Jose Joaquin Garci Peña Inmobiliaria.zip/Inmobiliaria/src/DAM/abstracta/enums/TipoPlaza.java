package DAM.abstracta.enums;

public enum TipoPlaza {
	PUBLICA,PRIVADA;
}
