package DAM.abstracta.enums;

public enum TipoConstruccion {
	NUEVA,SEGUNDA_MANO;
}
