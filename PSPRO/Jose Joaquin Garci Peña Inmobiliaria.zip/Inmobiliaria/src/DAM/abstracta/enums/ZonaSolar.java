package DAM.abstracta.enums;

public enum ZonaSolar {
	RUSTICA,URBANA;
}
